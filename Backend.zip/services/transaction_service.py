from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models.account import Account
from app.models.transaction import Transaction


def transfer_money(
    db: Session,
    user_id: int,
    from_account_id: int,
    to_account_id: int,
    amount
):
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Invalid amount")

    from_account = db.query(Account).filter(
        Account.id == from_account_id,
        Account.user_id == user_id
    ).first()

    if not from_account:
        raise HTTPException(status_code=404, detail="From account not found")

    to_account = db.query(Account).filter(
        Account.id == to_account_id
    ).first()

    if not to_account:
        raise HTTPException(status_code=404, detail="To account not found")

    if from_account.balance < amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    # update balances
    from_account.balance -= amount
    to_account.balance += amount

    transaction = Transaction(
        from_account_id=from_account_id,
        to_account_id=to_account_id,
        amount=amount,
        transaction_type="transfer",
        status="success"
    )

    db.add(transaction)
    db.commit()
    db.refresh(transaction)

    return transaction
