from sqlalchemy.orm import Session
from app.models.account import Account
from app.schemas.account import AccountCreate


def create_account(
    db: Session,
    user_id: int,
    data: AccountCreate
) -> Account:
    account = Account(
        user_id=user_id,
        bank_name=data.bank_name,
        account_type=data.account_type,
        masked_account=data.masked_account,
        currency=data.currency.upper(),
        balance=data.balance,
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


def get_accounts(db: Session, user_id: int) -> list[Account]:
    return (
        db.query(Account)
        .filter(Account.user_id == user_id)
        .all()
    )


def get_account(
    db: Session,
    user_id: int,
    account_id: int
) -> Account | None:
    return (
        db.query(Account)
        .filter(
            Account.user_id == user_id,
            Account.id == account_id
        )
        .first()
    )


def delete_account(
    db: Session,
    user_id: int,
    account_id: int
) -> Account | None:
    account = (
        db.query(Account)
        .filter(
            Account.user_id == user_id,
            Account.id == account_id
        )
        .first()
    )

    if not account:
        return None

    db.delete(account)
    db.commit()
    return account
