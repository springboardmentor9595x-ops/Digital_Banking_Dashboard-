from pydantic import BaseModel

class AccountCreate(BaseModel):
    bank_name: str
    account_type: str
    masked_account: str
    currency: str
    balance: float = 0.0


class AccountResponse(BaseModel):
    id: int
    bank_name: str
    account_type: str
    masked_account: str
    currency: str
    balance: float

    class Config:
        from_attributes = True
