# app/schemas/transaction.py
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

# Schema for creating a transaction


class TransactionCreate(BaseModel):
    account_id: int
    amount: float  # ✅ ensures a numeric type
    txn_type: str
    description: Optional[str] = None  # optional

# Schema for returning a transaction


class TransactionResponse(BaseModel):
    id: int
    account_id: int
    amount: float
    txn_type: str
    description: str
    created_at: datetime

    model_config = {
        "from_attributes": True  # replaces orm_mode=True in Pydantic v2
    }
