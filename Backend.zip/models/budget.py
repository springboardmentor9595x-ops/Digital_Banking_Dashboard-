# app/models/budget.py
from sqlalchemy import Column, Integer, Float
from app.db.base import Base


class Budget(Base):
    __tablename__ = "budgets"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer)
    month = Column(Integer)
    year = Column(Integer)
    budget_spent_amount = Column(Float, default=0.0)  # ✅ important
