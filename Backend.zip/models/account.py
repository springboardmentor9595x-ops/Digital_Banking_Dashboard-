# app/models/account.py
from sqlalchemy import Column, Integer, Float, String, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base


class Account(Base):
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    name = Column(String, nullable=False)
    balance_account = Column(Float, default=0.0)  # ✅ must be float

    user = relationship("User", back_populates="accounts")
    transactions = relationship("Transaction", back_populates="account")
