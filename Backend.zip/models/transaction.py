from sqlalchemy import Column, Integer, Float, String, ForeignKey
from sqlalchemy.orm import relationship
from app.db.base import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"))
    amount = Column(Float, nullable=False)
    txn_type = Column(String, nullable=False)  # 'credit' or 'debit'
    description = Column(String, nullable=True)

    account = relationship("Account", back_populates="transactions")
