from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.db.session import Base, engine

# Routers
from app.routers.auth_router import router as auth_router
from app.routers.user import router as user_router
from app.routers.accounts_router import router as accounts_router
from app.routers.budget_router import router as budget_router
from app.routers.transaction import router as transaction_router

# Force model imports
import app.models.user
import app.models.account
import app.models.budget
import app.models.transaction

app = FastAPI(
    title="Digital Banking API",
    version="1.0.0",
)

# Register routers
app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(user_router, prefix="/users", tags=["Users"])
app.include_router(accounts_router, prefix="/accounts", tags=["Accounts"])
app.include_router(budget_router, prefix="/budget", tags=["Budget"])
app.include_router(transaction_router, prefix="/transactions", tags=["Transactions"])

# Create DB tables
Base.metadata.create_all(bind=engine)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
