from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.models.account import Account
from app.schemas.account import AccountCreate, AccountResponse
from app.auth.dependencies import get_current_user


router = APIRouter(
    prefix="/accounts",
    tags=["Accounts"]
)

# ---------------- CREATE ACCOUNT ----------------


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_account(
    data: AccountCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    account = Account(
        user_id=user.id,
        bank_name=data.bank_name,
        account_type=data.account_type,
        masked_account=data.masked_account,
        currency=data.currency,
        balance=data.balance
    )
    db.add(account)
    db.commit()
    db.refresh(account)
    return account


# ---------------- GET ALL ACCOUNTS ----------------
@router.get("/", response_model=List[AccountResponse])
def get_accounts(
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    return db.query(Account).filter(Account.user_id == user.id).all()


# ---------------- GET ACCOUNT BY ID ----------------
@router.get("/{account_id}")
def get_account_by_id(
    account_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    account = db.query(Account).filter(
        Account.id == account_id,
        Account.user_id == user.id
    ).first()

    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found"
        )

    return account


# ---------------- UPDATE ACCOUNT ----------------
@router.put("/{account_id}")
def update_account(
    account_id: int,
    data: AccountCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    account = db.query(Account).filter(
        Account.id == account_id,
        Account.user_id == user.id
    ).first()

    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found"
        )

    account.bank_name = data.bank_name
    account.account_type = data.account_type
    account.masked_account = data.masked_account
    account.currency = data.currency
    account.balance = data.balance

    db.commit()
    db.refresh(account)
    return account


# ---------------- DELETE ACCOUNT ----------------
@router.delete("/{account_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_account(
    account_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user)
):
    account = db.query(Account).filter(
        Account.id == account_id,
        Account.user_id == user.id
    ).first()

    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found"
        )

    db.delete(account)
    db.commit()
    return None
