# app/routers/budget_router.py
from fastapi import APIRouter

router = APIRouter()


@router.get("budget/get")
def get_budget():
    return {"message": "Budget API is working!"}


@router.post("budget/post")
def create_budget(data: dict):
    return {"message": "Budget created", "data": data}
