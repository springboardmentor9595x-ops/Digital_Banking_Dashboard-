# app/routers/transactions.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime

from app.db.session import get_db
from app.auth.dependencies import get_current_user
from app.models.account import Account
from app.models.budget import Budget
from app.models.transaction import Transaction
from app.models.user import User
from app.schemas.transaction import TransactionCreate, TransactionResponse

router = APIRouter(prefix="/transactions", tags=["Transactions"])


# ---------------- CREATE TRANSACTION ----------------
@router.post(
    "/",
    response_model=TransactionResponse,
    status_code=status.HTTP_201_CREATED
)
def create_transaction(
    data: TransactionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    # Ensure account belongs to user
    account = (
        db.query(Account)
        .filter(
            Account.id == data.account_id,
            Account.user_id == user.id
        )
        .first()
    )
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found"
        )

    # Validate transaction type
    txn_type = data.txn_type.lower()
    if txn_type not in ["credit", "debit"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid transaction type"
        )

    # Convert amount to float
    try:
        amount = float(data.amount)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid transaction amount"
        )

    # Ensure account.balance is numeric
    if account.balance is None:
        account.balance = 0.0
    else:
        account.balance = float(account.balance)

    # Prepare budget
    current_month = datetime.utcnow().month
    current_year = datetime.utcnow().year
    budget = (
        db.query(Budget)
        .filter(
            Budget.user_id == user.id,
            Budget.month == current_month,
            Budget.year == current_year
        )
        .first()
    )
    if budget:
        if budget.spent_amount is None:
            budget.spent_amount = 0.0
        else:
            budget.spent_amount = float(budget.spent_amount)

    # Update account balance and budget
    if txn_type == "credit":
        account.balance += amount
    else:  # debit
        if account.balance < amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Insufficient balance"
            )
        account.balance -= amount
        if budget:
            budget.spent_amount += amount

    # Create transaction record
    txn = Transaction(
        account_id=account.id,
        amount=amount,
        txn_type=txn_type,
        description=data.description
    )

    db.add(txn)
    db.commit()
    db.refresh(txn)
    db.refresh(account)
    if budget:
        db.refresh(budget)

    return txn


# ---------------- GET ALL TRANSACTIONS ----------------
@router.get("/", response_model=List[TransactionResponse])
def get_transactions(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    transactions = (
        db.query(Transaction)
        .join(Account, Transaction.account_id == Account.id)
        .filter(Account.user_id == user.id)
        .all()
    )
    return transactions


# ---------------- GET TRANSACTIONS BY ACCOUNT ----------------
@router.get("/account/{account_id}", response_model=List[TransactionResponse])
def get_transactions_by_account(
    account_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    account = (
        db.query(Account)
        .filter(
            Account.id == account_id,
            Account.user_id == user.id
        )
        .first()
    )
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found"
        )

    transactions = (
        db.query(Transaction)
        .filter(Transaction.account_id == account_id)
        .all()
    )
    return transactions
