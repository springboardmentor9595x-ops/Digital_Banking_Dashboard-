# app/routes/user.py
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import List
from app.services.auth_service import get_current_user


# Create router
router = APIRouter(
    prefix="/users",
    tags=["Users"]
)

# Pydantic models


class User(BaseModel):
    id: int
    name: str
    email: str


class UserCreate(BaseModel):
    name: str
    email: str

# In-memory database (replace with real DB later)


fake_users_db = [
    {"id": 1, "name": "Saisri Mothe", "email": "saisri@test.com"},
    {"id": 2, "name": "John Doe", "email": "john@example.com"},
]

# -------------------------------
# GET all users (protected)
# -------------------------------


@router.get("/", response_model=List[User])
def get_users(current_user: str = Depends(get_current_user)):
    """
    Get all users.
    Requires a valid JWT token.
    """
    return fake_users_db

# -------------------------------
# GET user by ID (protected)
# -------------------------------


@router.get("/{user_id}", response_model=User)
def get_user(user_id: int, current_user: str = Depends(get_current_user)):
    """
    Get a single user by ID.
    Requires a valid JWT token.
    """
    for user in fake_users_db:
        if user["id"] == user_id:
            return user
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="User not found"
    )

# -------------------------------
# CREATE a new user (protected)
# -------------------------------


@router.post("/", response_model=User, status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate, current_user: str = Depends(get_current_user)):
    """
    Create a new user.
    Requires a valid JWT token.
    """
    new_id = max([u["id"] for u in fake_users_db]) + 1 if fake_users_db else 1
    new_user = {"id": new_id, "name": user.name, "email": user.email}
    fake_users_db.append(new_user)
    return new_user

# -------------------------------
# DELETE a user (protected)
# -------------------------------


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, current_user: str = Depends(get_current_user)):
    """
    Delete a user by ID.
    Requires a valid JWT token.
    """
    for index, user in enumerate(fake_users_db):
        if user["id"] == user_id:
            fake_users_db.pop(index)
            return
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="User not found"
    )
