from fastapi import APIRouter

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"]
)


@router.post("/register")
def register():
    return {"msg": "registered"}


@router.post("/login")
def login():
    return {"msg": "logged in"}


@router.post("/refresh")
def refresh_token():
    return {"msg": "token refreshed"}
